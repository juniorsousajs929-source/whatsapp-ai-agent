const secrets = require('../config/secrets'); // Read from committed file
require('dotenv').config();

// Load all keys from secrets.js or .env fallback
function loadKeys() {
    let keys = [];

    // Priority: secrets.js (Hardcoded)
    if (secrets.GEMINI_KEYS && secrets.GEMINI_KEYS.length > 0) {
        console.log("KeyManager loaded API Keys from secrets.js (Hardcoded)");
        return secrets.GEMINI_KEYS;
    }

    // Fallback: .env
    if (process.env.GEMINI_API_KEY) keys.push(process.env.GEMINI_API_KEY);
    let i = 1;
    while (process.env[`GEMINI_KEY_${i}`]) {
        keys.push(process.env[`GEMINI_KEY_${i}`]);
        i++;
    }

    if (keys.length === 0) {
        console.error("CRITICAL: No GEMINI_API_KEY found!");
    } else {
        console.log(`KeyManager loaded ${keys.length} API Keys from .env.`);
    }

    return keys;
}

const keys = loadKeys();
let currentIndex = 0;

module.exports = {
    // Round-Robin Strategy: Get next key in the list
    getNextKey: () => {
        if (keys.length === 0) return null;

        const key = keys[currentIndex];
        // Move index to next, loop back to 0 if at end
        currentIndex = (currentIndex + 1) % keys.length;
        return key;
    },

    // Get current pool size (for debugging)
    getPoolSize: () => keys.length
};
